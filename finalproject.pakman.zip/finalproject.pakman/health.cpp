#include "health.h"

health::health()
{
}

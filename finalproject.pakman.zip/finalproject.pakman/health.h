#ifndef HEALTH_H
#define HEALTH_H

class health
{
public:
    health();
};

#endif // HEALTH_H

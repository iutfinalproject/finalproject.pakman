#ifndef CREATURE_H
#define CREATURE_H
#include<QObject>
#include<QGraphicsPixmapItem>
#include<QGraphicsItem>
#include<QList>
#include<typeinfo>
class creature:public QObject ,public QGraphicsPixmapItem{
Q_OBJECT
public:
    explicit creature(QGraphicsPixmapItem *parent2= 0);
   bool accident();
protected:
    int x;
    int y;
  QPixmap *creature_img;



};
#endif // CREATURE_H

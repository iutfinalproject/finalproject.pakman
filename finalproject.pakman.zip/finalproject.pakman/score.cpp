#include "score.h"

score::score()
{
}

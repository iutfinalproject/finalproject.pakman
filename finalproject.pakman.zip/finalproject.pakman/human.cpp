#include"human.h"
#include "creature.h"
#include"brick.h"
#include <QGraphicsScene>
#include<QDesktopWidget>
human::human(QGraphicsPixmapItem *parent2):creature(parent2)/*,  QObject(),QGraphicsPixmapItem(parent2)*/{

     QDesktopWidget desktop;
     y=desktop.geometry().height()/15;
    x=(desktop.geometry().width()/2.3);
    int h=desktop.geometry().height()/13;
            int w=(desktop.geometry().width()/14);
    creature_img=new QPixmap("://image/human3.png");
       * creature_img= creature_img->scaled(w,h);
      setPixmap(*creature_img);
         this->setPos(x,y);

}

void human::keyPressEvent(QKeyEvent *event)
{
    QDesktopWidget desktop;
    int h=desktop.geometry().height()/12;
    int w=(desktop.geometry().width()/14);
    if(event->key()==Qt::Key_Up){
        y-=5;
        creature_img=new QPixmap("://image/human4.png");
        * creature_img= creature_img->scaled(w,h);
        setPixmap(*creature_img);
        setPos(x,y);
        if(this->accident()==true){
          y+=5;
          setPos(x,y);
        }


    }

    if(event->key()==Qt::Key_Down){
        y+=5;
        creature_img=new QPixmap("://image/human3.png");
        * creature_img= creature_img->scaled(w,h);
        setPixmap(*creature_img);
       setPos(x,y);
       if(this->accident()==true){
         y-=5;
         setPos(x,y);
       }

    }

    if(event->key()==Qt::Key_Right){
        x+=5;
        creature_img=new QPixmap("://image/human1.png");
        * creature_img= creature_img->scaled(w,h);
        setPixmap(*creature_img);
       setPos(x,y);
       if(this->accident()==true){
         x-=5;
         setPos(x,y);
       }

    }

    if(event->key()==Qt::Key_Left){
        x-=5;
        creature_img=new QPixmap("://image/human2.png");
        * creature_img= creature_img->scaled(w,h);
        setPixmap(*creature_img);
         setPos(x,y);
         if(this->accident()==true){
           x+=5;
           setPos(x,y);
         }

    }

}




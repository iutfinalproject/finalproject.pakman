#ifndef ADDKEY2_H
#define ADDKEY2_H
#include"addkey2.h"
#include<QDesktopWidget>
#include<QGraphicsScene>
void addbrick2(QGraphicsScene* scene){



}
#endif // ADDKEY2_H

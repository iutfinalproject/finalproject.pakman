#ifndef SCORE_H
#define SCORE_H

class score
{
public:
    score();
};

#endif // SCORE_H

#include"creature.h"
#include"brick.h"
#include<typeinfo>

creature::creature(QGraphicsPixmapItem *parent2):QObject(),QGraphicsPixmapItem(parent2)
{

}

bool creature::accident()
{
    QList<QGraphicsItem*> collidingItem_=collidingItems() ;
 for(int i=0;i<(collidingItem_.size());++i){
     //if(typeid(*(collidingItem_[i])==typeid(brick))){
        // return true;
    // }
 }
 return false;
}


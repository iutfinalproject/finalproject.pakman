#ifndef BACKGROUND_H
#define BACKGROUND_H
#include <QObject>
#include <QGraphicsScene>
#include"player_1.h"
#include"player_2.h"
class background : public QObject
{
    Q_OBJECT
public:
    explicit background(QObject *parent = 0, QGraphicsScene *nowscene=0, int nowid=0);
      void addbrick();
      void addkey();
      void adddestroyer();
      void addtreasure();
      void addscore();
      void addHealth();
      void page_of_start();
      void addplayer();
      char*getplayeraddress(){return player_address;}
      void middle_page(int );
      void setscene();
//         scene=nullptr;
//         scene=_scene;
//     }

      void setid(int)/*{id=_id*/;
      int id;

  private:
      QGraphicsScene* scene;

      int desktopHight;
      int desktopWidth;
      char*player_address;
      player_1 *player11_;
      player_1 *player12_;
      player_1 *player13_;
      player_2 *player21_;
      player_2 *player22_;
      player_2 *player23_;
signals:
     void send_calculate1();
     void send_calculate2();
     void send_calculate3();

};


#endif // BACKGROUND_H

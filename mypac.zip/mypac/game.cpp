#include "game.h"
#include"destroyer.h"
#include"startpage.h"
QGraphicsView* Game::view=0;
//QGraphicsScene* Game::scene=0;
Game::Game(QWidget *parent)
{
    view=new QGraphicsView();
    scene=new QGraphicsScene();
    view->setScene(scene);
    QDesktopWidget desktop;
    int desktopHight=desktop.geometry().height();
    int desktopWidth=desktop.geometry().width();
    view->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view->setFixedSize(desktopWidth,desktopHight);
     qDebug()<<"i am here";





//    scene->setSceneRect(0,0,desktopWidth,desktopHight);
//    QImage background2(":/image/background2.png");
//    scene->setBackgroundBrush(background2.scaled(desktopWidth,desktopHight));
//    background *mybackground=new background(0,scene,0);
//    mybackground->page_of_start();


}

void Game::start_page()
{
    _background=new background(0,scene,0);

    QDesktopWidget desktop;
    int desktopHight=desktop.geometry().height();
    int desktopWidth=desktop.geometry().width();
     qDebug()<<"i am startpage";
    scene->setSceneRect(0,0,desktopWidth,desktopHight);
    QImage background2(":/image/background2.png");
    scene->setBackgroundBrush(background2.scaled(desktopWidth,desktopHight));
   // background *mybackground=new background(0,scene,0);
    _background->page_of_start();
    view->setScene(scene);

}

void Game::ricive_set_step1()
{
//      QList<QGraphicsItem*> itemsList = scene->items();
//      QList<QGraphicsItem*>::iterator iter = itemsList.begin();
//      QList<QGraphicsItem*>::iterator end = itemsList.end();
//      while(iter != end)
//        {
//          QGraphicsItem* item = (*iter);
//          delete item;
//          iter++;
//        }
  //  _background->setscene();
      _background->setid(1);
    qDebug()<<"i am in set step one in game";
    int select_page=0;
    QDesktopWidget desktop;
    int desktopHight=desktop.geometry().height();
    int desktopWidth=desktop.geometry().width();
    scene->setSceneRect(0,0,desktopWidth,desktopHight);
    QImage background1(":/image/background2.png");
    scene->setBackgroundBrush(background1.scaled(desktopWidth,desktopHight));
   // background* _background=new background(0,scene,1);
    _background->setid(1);
    _background->addbrick();
    _background->adddestroyer();
    _background->addkey();
    view->setScene(scene);
}

void Game::ricive_set_step2()
{
    qDebug()<<"i am in set step two in game";


    //    scene2->setSceneRect(0,0,desktopWidth,desktopHight);
    //    QImage background2(":/image/background2.png");
    //    scene2->setBackgroundBrush(background2.scaled(desktopWidth,desktopHight));
    //    background mybackground(select_page,0,scene2,2);
    //    mybackground.addbrick();
    //    QThread myt;
    //    my_thread ob(scene2);
    // mybackground.addkey();
    //    ob.dowork(myt);
    //    ob.moveToThread(&myt);

    //    myt.start();

    //   // mybackground.adddestroyer();

    //    mybackground.addscore();
    //    mybackground.addHealth();
    //    mybackground.addtreasure();
    //    mybackground.addplayer();
    //    view->setScene(scene2);

}

void Game::ricive_set_step3()
{
    qDebug()<<"i am set step3";
    QDesktopWidget desktop;
    int desktopHight=desktop.geometry().height();
    int desktopWidth=desktop.geometry().width();
    scene->setSceneRect(0,0,desktopWidth,desktopHight);
    QImage background3(":/image/background2.png");
    scene->setBackgroundBrush(background3.scaled(desktopWidth,desktopHight));
   // background* mybackground=new background(0,scene,3);
    _background->setscene();
      _background->setid(3);
    _background->addbrick();
    _background->addkey();
    _background->adddestroyer();
    view->setScene(scene);
}

void Game::ricive_set_step4()
{
}










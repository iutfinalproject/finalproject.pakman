#ifndef GAME_H
#define GAME_H
#include<QWidget>
#include <QGraphicsView>
#include<QGraphicsScene>
#include<QDesktopWidget>
#include<qdebug.h>
#include"background.h"
#include"player.h"
#include"key.h"
#include"brick.h"
#include"background.h"
class Game:public QObject {
    Q_OBJECT
public:
    Game(QWidget*parent=0);
   QGraphicsScene* scene;
    static QGraphicsView* view;
    void start_page();
private:
    background* _background;
public slots:
    void ricive_set_step1();
    void ricive_set_step2();
    void ricive_set_step3();
    void ricive_set_step4();


};

#endif // GAME_H

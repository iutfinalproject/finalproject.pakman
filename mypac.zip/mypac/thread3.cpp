//#include "thread3.h"
//#include<QDebug>

//thread3::thread3(QObject *parent) :player1(100,200,0),player2(200,100,0),
//    QObject(parent)
//{
//}
//void thread3::moveplayer(){
//player1.keyPressEvent();
//player2.keyPressEvent();
//}
//void thread3::dowork(QThread &cthread){
//    connect(&cthread,SIGNAL(started()),this,SLOT(moveplayer()));
//}

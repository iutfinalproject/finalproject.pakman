//#ifndef THREAD3_H
//#define THREAD3_H

//#include <QObject>
//#include<QGraphicsScene>
//#include<QThread>
//#include"player_1.h"
//#include"player_2.h"

//class thread3 : public QObject
//{
//    Q_OBJECT
//public:
//    explicit thread3(QObject *parent = 0);
//    void dowork(QThread & cthread);


//public slots:
//     void moveplayer();


//private:
//     player_1 player1;
//     player_2 player2;

//};

//#endif // thread2_H
